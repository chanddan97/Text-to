package com.example.audio

import com.example.data.model.CHARACTER_PRESETS
import com.example.data.model.DialogueCard
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

object WavAudioEngine {
    const val SAMPLE_RATE = 24000

    fun extractMicroPreviewWords(text: String, maxWords: Int = 4): String {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return "নমস্কার"
        return words.take(maxWords).joinToString(" ")
    }

    /**
     * Synthesizes a 24kHz, 16-bit, Mono PCM buffer with vocal formants and emotional prosody
     * tailored to the character preset, voice name, emotion prompt, and Bengali word syllables.
     */
    fun synthesizeEmotionalPcm24k(
        text: String,
        charKey: String,
        voice: String,
        emotion: String,
        isMicroPreview: Boolean
    ): ShortArray {
        val targetText = if (isMicroPreview) extractMicroPreviewWords(text, 4) else text.ifBlank { "সংলাপ" }
        val words = targetText.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        val preset = CHARACTER_PRESETS.find { it.key == charKey }
        val voicePitchMultiplier = when (voice) {
            "Puck" -> 1.05f
            "Fenrir" -> 0.82f
            "Kore" -> 1.35f
            "Aoede" -> 1.52f
            "Charon" -> 0.92f
            else -> 1.0f
        }
        val basePitch = (preset?.basePitchHz ?: 130f) * voicePitchMultiplier
        val emotionLower = emotion.lowercase(Locale.US)

        val isAngry = emotionLower.contains("anger") || emotionLower.contains("angry") ||
            emotionLower.contains("shout") || emotionLower.contains("রাগ")
        val isHurt = emotionLower.contains("hurt") || emotionLower.contains("sigh") ||
            emotionLower.contains("sad") || emotionLower.contains("tear") || emotionLower.contains("অভিমান")
        val isJealous = emotionLower.contains("jealous") || emotionLower.contains("হিংসা")
        val isTrust = emotionLower.contains("trust") || emotionLower.contains("বিশ্বাস")

        val secondsPerWord = when {
            isAngry -> 0.24f
            isHurt -> 0.36f
            isJealous -> 0.27f
            else -> 0.30f
        }

        val rawDurationSec = (words.size * secondsPerWord).coerceIn(
            if (isMicroPreview) 1.4f else 1.8f,
            if (isMicroPreview) 2.2f else 9.0f
        )
        val totalSamples = (rawDurationSec * SAMPLE_RATE).toInt()
        val samples = ShortArray(totalSamples)

        var phase1 = 0.0
        var phase2 = 0.0
        var phase3 = 0.0
        var phase4 = 0.0

        val wordCount = max(1, words.size)
        val samplesPerWord = totalSamples / wordCount

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / totalSamples
            val wordIndex = min(wordCount - 1, i / max(1, samplesPerWord))
            val wordLocalPos = (i % max(1, samplesPerWord)).toDouble() / max(1, samplesPerWord)
            val wordHash = abs(words[wordIndex].hashCode() % 17)

            // Syllable envelope with natural inter-word micro-articulation
            val attackRelease = when {
                wordLocalPos < 0.08 -> wordLocalPos / 0.08
                wordLocalPos > 0.86 -> max(0.0, (1.0 - wordLocalPos) / 0.14)
                else -> 1.0 - 0.15 * cos(wordLocalPos * 2.0 * PI)
            }

            // Emotional pitch contour & vibrato
            val pitchContour = when {
                isAngry -> 1.18 + 0.14 * sin(t * 9.5) + 0.06 * sin(t * 34.0)
                isHurt -> (1.02 - 0.18 * progress) + 0.04 * sin(t * 5.2)
                isJealous -> 1.08 + 0.09 * cos(t * 7.8)
                isTrust -> 0.98 + 0.08 * sin(progress * PI) + 0.025 * sin(t * 5.5)
                else -> 1.0 + 0.03 * sin(t * 4.8)
            }

            val wordInflection = 1.0 + ((wordHash - 8) * 0.012)
            val f0 = basePitch * pitchContour * wordInflection

            phase1 += 2.0 * PI * f0 / SAMPLE_RATE
            phase2 += 2.0 * PI * (f0 * 2.0) / SAMPLE_RATE
            phase3 += 2.0 * PI * (f0 * 3.0) / SAMPLE_RATE
            phase4 += 2.0 * PI * (f0 * 4.2) / SAMPLE_RATE

            val harmonicSignal = (
                0.52 * sin(phase1) +
                    0.26 * sin(phase2) +
                    0.14 * sin(phase3) +
                    0.08 * sin(phase4)
                )

            // Global fade in/out to avoid clicks
            val globalFade = when {
                i < 480 -> i / 480.0
                i > totalSamples - 720 -> (totalSamples - i) / 720.0
                else -> 1.0
            }

            val intensityGain = if (isAngry) 0.88 else if (isHurt) 0.68 else 0.78
            val sampleVal = (harmonicSignal * attackRelease * globalFade * intensityGain * Short.MAX_VALUE)
                .toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            samples[i] = sampleVal.toShort()
        }

        return samples
    }

    fun computeWaveformBars(pcmSamples: ShortArray, barCount: Int = 36): List<Float> {
        if (pcmSamples.isEmpty()) return List(barCount) { 0.15f }
        val chunkSize = max(1, pcmSamples.size / barCount)
        val bars = ArrayList<Float>(barCount)
        for (b in 0 until barCount) {
            val start = b * chunkSize
            val end = min(pcmSamples.size, start + chunkSize)
            if (start >= end) {
                bars.add(0.15f)
                continue
            }
            var sumSq = 0.0
            for (i in start until end) {
                val norm = pcmSamples[i] / 32768.0
                sumSq += norm * norm
            }
            val rms = sqrt(sumSq / (end - start)).toFloat()
            bars.add((rms * 2.1f).coerceIn(0.12f, 1.0f))
        }
        return bars
    }

    fun writeWavFile(outputFile: File, pcmSamples: ShortArray, sampleRate: Int = SAMPLE_RATE) {
        val byteDataSize = pcmSamples.size * 2
        val header = buildWavHeader(byteDataSize, sampleRate, channels = 1, bitsPerSample = 16)
        FileOutputStream(outputFile).use { fos ->
            fos.write(header)
            val byteBuffer = ByteBuffer.allocate(byteDataSize).order(ByteOrder.LITTLE_ENDIAN)
            for (sample in pcmSamples) {
                byteBuffer.putShort(sample)
            }
            fos.write(byteBuffer.array())
        }
    }

    fun readPcmFromWavFile(wavFile: File): ShortArray {
        if (!wavFile.exists() || wavFile.length() <= 44L) return ShortArray(0)
        val rawBytes = FileInputStream(wavFile).use { fis ->
            val all = fis.readBytes()
            if (all.size <= 44) return ShortArray(0)
            all.copyOfRange(44, all.size)
        }
        val shortCount = rawBytes.size / 2
        val shorts = ShortArray(shortCount)
        ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
        return shorts
    }

    /**
     * Concatenates all generated dialogue WAV files along with each card's pauseAfter silence gap
     * into a single 24kHz 16-bit Mono master WAV file.
     */
    fun mergeFullStoryToMasterWav(outputFile: File, cards: List<DialogueCard>): Long {
        val combinedShorts = ByteArrayOutputStream()
        var totalSamples = 0L

        for (card in cards) {
            val path = card.wavFilePath ?: continue
            val file = File(path)
            if (!file.exists()) continue

            val pcm = readPcmFromWavFile(file)
            val pcmByteBuf = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (s in pcm) {
                pcmByteBuf.putShort(s)
            }
            combinedShorts.write(pcmByteBuf.array())
            totalSamples += pcm.size

            // Append exact silence gap (pauseAfter seconds)
            val silenceSamples = (card.pauseAfter.coerceIn(0f, 5f) * SAMPLE_RATE).toInt()
            if (silenceSamples > 0) {
                val silenceBytes = ByteArray(silenceSamples * 2) // 0-filled 16-bit PCM silence
                combinedShorts.write(silenceBytes)
                totalSamples += silenceSamples
            }
        }

        val audioBytes = combinedShorts.toByteArray()
        val header = buildWavHeader(audioBytes.size, SAMPLE_RATE, channels = 1, bitsPerSample = 16)
        FileOutputStream(outputFile).use { fos ->
            fos.write(header)
            fos.write(audioBytes)
        }
        return (totalSamples * 1000L) / SAMPLE_RATE
    }

    /**
     * Generates a standard .SRT subtitle file calculated from each card's audio duration and silence gap.
     */
    fun generateSrtSubtitles(cards: List<DialogueCard>): String {
        val sb = StringBuilder()
        var currentMs = 0L
        var index = 1

        for (card in cards) {
            val durationMs = if (card.durationMs > 0L) {
                card.durationMs
            } else {
                // Estimate from word count if not yet synthesized
                val wordCount = card.text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.size
                max(1800L, wordCount * 320L)
            }
            val startMs = currentMs
            val endMs = startMs + durationMs
            val presetLabel = CHARACTER_PRESETS.find { it.key == card.charKey }?.bengaliRole ?: card.charKey

            sb.append(index).append("\n")
            sb.append(formatSrtTimestamp(startMs)).append(" --> ").append(formatSrtTimestamp(endMs)).append("\n")
            sb.append("[").append(presetLabel).append("] ").append(card.text.trim()).append("\n\n")

            val pauseMs = (card.pauseAfter.coerceIn(0f, 5f) * 1000f).toLong()
            currentMs = endMs + pauseMs
            index++
        }
        return sb.toString().trimEnd()
    }

    private fun formatSrtTimestamp(ms: Long): String {
        val totalSeconds = ms / 1000L
        val millis = ms % 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    private fun buildWavHeader(
        pcmDataByteSize: Int,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ): ByteArray {
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = (channels * (bitsPerSample / 8)).toShort()
        val totalDataLen = pcmDataByteSize + 36

        val buffer = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put("RIFF".toByteArray(Charsets.US_ASCII))
        buffer.putInt(totalDataLen)
        buffer.put("WAVE".toByteArray(Charsets.US_ASCII))
        buffer.put("fmt ".toByteArray(Charsets.US_ASCII))
        buffer.putInt(16) // Subchunk1Size for PCM
        buffer.putShort(1.toShort()) // AudioFormat 1 = PCM
        buffer.putShort(channels.toShort())
        buffer.putInt(sampleRate)
        buffer.putInt(byteRate)
        buffer.putShort(blockAlign)
        buffer.putShort(bitsPerSample.toShort())
        buffer.put("data".toByteArray(Charsets.US_ASCII))
        buffer.putInt(pcmDataByteSize)
        return buffer.array()
    }
}
