package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Locale

class StudioAudioPlayer(context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null

    private val _isTtsReady = MutableStateFlow(false)
    val isTtsReady: StateFlow<Boolean> = _isTtsReady.asStateFlow()

    private val _playingFilePath = MutableStateFlow<String?>(null)
    val playingFilePath: StateFlow<String?> = _playingFilePath.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val bnIn = Locale.forLanguageTag("bn-IN")
                val bnBd = Locale.forLanguageTag("bn-BD")
                val result = tts?.setLanguage(bnIn) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val bdResult = tts?.setLanguage(bnBd) ?: TextToSpeech.LANG_NOT_SUPPORTED
                    if (bdResult == TextToSpeech.LANG_MISSING_DATA || bdResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.language = Locale.US
                    }
                }
                _isTtsReady.value = true
            }
        }
    }

    fun playWavFile(filePath: String, onCompletion: () -> Unit = {}) {
        stopPlayback()
        val file = File(filePath)
        if (!file.exists()) {
            onCompletion()
            return
        }
        try {
            val mp = MediaPlayer()
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener {
                _playingFilePath.value = null
                onCompletion()
            }
            mp.setOnErrorListener { _, _, _ ->
                _playingFilePath.value = null
                onCompletion()
                true
            }
            mp.prepare()
            mp.start()
            mediaPlayer = mp
            _playingFilePath.value = filePath
        } catch (_: Exception) {
            _playingFilePath.value = null
            onCompletion()
        }
    }

    fun speakOfflineDraft(text: String, charKey: String, emotion: String) {
        stopPlayback()
        val engine = tts ?: return
        val emotionLower = emotion.lowercase(Locale.US)
        val pitch = when (charKey) {
            "young_28" -> 1.08f
            "old_60" -> 0.78f
            "mother_50" -> 1.24f
            "female_25" -> 1.38f
            else -> 0.92f
        }
        val speechRate = when {
            emotionLower.contains("anger") || emotionLower.contains("fast") -> 1.18f
            emotionLower.contains("hurt") || emotionLower.contains("slow") -> 0.84f
            else -> 0.98f
        }
        engine.setPitch(pitch)
        engine.setSpeechRate(speechRate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "offline_draft_${System.currentTimeMillis()}")
    }

    fun stopPlayback() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
        _playingFilePath.value = null
    }

    fun release() {
        stopPlayback()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
    }
}
