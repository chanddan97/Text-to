package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudioDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF00262E),
    primaryContainer = NeonCyanDim,
    onPrimaryContainer = Color(0xFFB8F8FF),
    secondary = ElectricViolet,
    onSecondary = Color(0xFF1F0942),
    secondaryContainer = ElectricVioletDim,
    onSecondaryContainer = Color(0xFFEBDDFF),
    tertiary = WarmAmber,
    onTertiary = Color(0xFF3E2400),
    background = StudioObsidian,
    onBackground = TextPrimary,
    surface = StudioSurface,
    onSurface = TextPrimary,
    surfaceVariant = StudioSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = StudioGlassBorder,
    error = DramaticCoral
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudioDarkColorScheme,
        typography = Typography,
        content = content
    )
}
