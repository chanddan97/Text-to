package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ANALYZER_MODELS
import com.example.data.model.DiagnosticsReport
import com.example.data.model.TTS_MODELS
import com.example.ui.theme.DramaticCoral
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.StudioGlassBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmAmber

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioTopHeader(
    selectedAnalyzerModel: String,
    selectedTtsModel: String,
    activeSlotIndex: Int,
    rotationBanner: String,
    aiNoticeMessage: String,
    onSelectAnalyzerModel: (String) -> Unit,
    onSelectTtsModel: (String) -> Unit,
    onOpenKeyManager: () -> Unit,
    onSaveDebugApk: () -> Unit,
    onSimulate429Rotate: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onLockStudio: () -> Unit
) {
    var showAnalyzerMenu by remember { mutableStateOf(false) }
    var showTtsMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurface)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Row 1: App Title + Diagnostics & Lock Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = NeonCyan.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, NeonCyan)
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "AI Emotional Voice Studio Pro",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "24kHz PCM • Bengali Acting Director • SRT",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onOpenKeyManager,
                    modifier = Modifier.testTag("open_key_manager_top_icon")
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = "Manual API Key Input & Test",
                        tint = NeonCyan
                    )
                }
                IconButton(
                    onClick = onOpenDiagnostics,
                    modifier = Modifier.testTag("open_diagnostics_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = "System Diagnostics & Health Check",
                        tint = EmeraldMint
                    )
                }
                IconButton(
                    onClick = onLockStudio,
                    modifier = Modifier.testTag("lock_studio_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock Studio",
                        tint = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Row 2: Model Switchers & Multi-Slot Rotation Manager
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Analyzer Model Switcher
            Box {
                Surface(
                    modifier = Modifier
                        .clickable { showAnalyzerMenu = true }
                        .testTag("analyzer_model_dropdown"),
                    shape = RoundedCornerShape(10.dp),
                    color = StudioSurfaceElevated,
                    border = BorderStroke(1.dp, StudioGlassBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Director: $selectedAnalyzerModel ▾",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary
                        )
                    }
                }
                DropdownMenu(
                    expanded = showAnalyzerMenu,
                    onDismissRequest = { showAnalyzerMenu = false }
                ) {
                    ANALYZER_MODELS.forEach { model ->
                        DropdownMenuItem(
                            text = { Text(model) },
                            onClick = {
                                onSelectAnalyzerModel(model)
                                showAnalyzerMenu = false
                            }
                        )
                    }
                }
            }

            // TTS Model Switcher
            Box {
                Surface(
                    modifier = Modifier
                        .clickable { showTtsMenu = true }
                        .testTag("tts_model_dropdown"),
                    shape = RoundedCornerShape(10.dp),
                    color = StudioSurfaceElevated,
                    border = BorderStroke(1.dp, StudioGlassBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TTS: $selectedTtsModel ▾",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricViolet
                        )
                    }
                }
                DropdownMenu(
                    expanded = showTtsMenu,
                    onDismissRequest = { showTtsMenu = false }
                ) {
                    TTS_MODELS.forEach { model ->
                        DropdownMenuItem(
                            text = { Text(model) },
                            onClick = {
                                onSelectTtsModel(model)
                                showTtsMenu = false
                            }
                        )
                    }
                }
            }

            // Manual API Key Input & Test Pill
            Surface(
                modifier = Modifier
                    .clickable { onOpenKeyManager() }
                    .testTag("open_key_manager_button"),
                shape = RoundedCornerShape(10.dp),
                color = NeonCyan.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, NeonCyan)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "API Key: Input / Test & Add",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Multi-Slot Failover Pill
            Surface(
                modifier = Modifier
                    .clickable { onSimulate429Rotate() }
                    .testTag("rotate_key_slot_button"),
                shape = RoundedCornerShape(10.dp),
                color = WarmAmber.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, WarmAmber.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.SyncAlt,
                        contentDescription = null,
                        tint = WarmAmber,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Slot #${activeSlotIndex + 1} Active (429 Rotate)",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmAmber
                    )
                }
            }

            // Save debug.apk Pill
            Surface(
                modifier = Modifier
                    .clickable { onSaveDebugApk() }
                    .testTag("save_debug_apk_button"),
                shape = RoundedCornerShape(10.dp),
                color = EmeraldMint.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, EmeraldMint)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        tint = EmeraldMint,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Save debug.apk",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldMint,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Mandatory In-App Notice for Sample AI Output (since Firebase setup was declined)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("firebase_ai_notice_banner"),
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF1A243B),
            border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = aiNoticeMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = rotationBanner,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticsBottomSheet(
    report: DiagnosticsReport?,
    isRunning: Boolean,
    onRerunCheck: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StudioSurface,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = null,
                        tint = EmeraldMint
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "System Diagnostics & API Health",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                }
                IconButton(
                    onClick = onRerunCheck,
                    modifier = Modifier.testTag("rerun_diagnostics_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Re-run Diagnostics",
                        tint = NeonCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isRunning || report == null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = NeonCyan)
                }
            } else {
                DiagnosticRowItem(
                    title = "24kHz 16-bit Mono PCM WAV Engine",
                    value = if (report.pcmAudioEngineReady) "READY (24,000 Hz RIFF/WAVE)" else "ERROR",
                    isHealthy = report.pcmAudioEngineReady
                )
                DiagnosticRowItem(
                    title = "Instant Offline TTS (bn-IN / bn-BD)",
                    value = if (report.offlineTtsReady) "ONLINE & INITIALIZED" else "INITIALIZING",
                    isHealthy = report.offlineTtsReady
                )
                DiagnosticRowItem(
                    title = "Local Room DB (Voice Clip Archive)",
                    value = "CONNECTED (${report.localDbClipCount} clips saved)",
                    isHealthy = report.localDbConnected
                )
                DiagnosticRowItem(
                    title = "Background Notification Permission",
                    value = if (report.notificationPermissionGranted) "GRANTED" else "NOT GRANTED",
                    isHealthy = report.notificationPermissionGranted
                )
                DiagnosticRowItem(
                    title = "Multi-Slot Rotation Manager",
                    value = "Slot #${report.activeKeySlotIndex + 1} of ${report.configuredKeyCount} Active",
                    isHealthy = true
                )
                DiagnosticRowItem(
                    title = "AI Repository Pipeline Latency",
                    value = "${report.pingLatencyMs} ms • ${report.aiStatusSummary}",
                    isHealthy = true
                )

                if (!report.notificationPermissionGranted) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = onRequestNotificationPermission,
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, NeonCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = NeonCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Grant System Notification Permission", color = NeonCyan)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DiagnosticRowItem(
    title: String,
    value: String,
    isHealthy: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = BorderStroke(1.dp, StudioGlassBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isHealthy) EmeraldMint else WarmAmber
                )
            }
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = if (isHealthy) EmeraldMint else WarmAmber,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun SrtExportDialog(
    srtContent: String,
    onDismiss: () -> Unit,
    onShareSrt: (String) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurface,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Text(
                text = "Exported .SRT Subtitles (CapCut / VN / Reels)",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Timestamps calculated automatically from 24kHz audio clip durations and silence gaps:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = StudioSurfaceElevated,
                    border = BorderStroke(1.dp, StudioGlassBorder)
                ) {
                    Text(
                        text = srtContent,
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onShareSrt(srtContent) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = Color(0xFF00222B)
                )
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share / Export .SRT")
            }
        },
        dismissButton = {
            Row {
                TextButton(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(srtContent))
                    }
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy", color = ElectricViolet)
                }
                TextButton(onClick = onDismiss) {
                    Text("Close", color = TextSecondary)
                }
            }
        }
    )
}
