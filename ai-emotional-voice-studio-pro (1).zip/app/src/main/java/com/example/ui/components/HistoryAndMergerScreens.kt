package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.audio.WavAudioEngine
import com.example.data.local.VoiceClipEntity
import com.example.data.model.CHARACTER_PRESETS
import com.example.data.model.DialogueCard
import com.example.ui.theme.DramaticCoral
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.StudioGlassBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MasterMergerAndSrtScreen(
    cards: List<DialogueCard>,
    isBatchGenerating: Boolean,
    batchCompleted: Int,
    batchTotal: Int,
    mergedMasterWavPath: String?,
    mergedMasterDurationMs: Long,
    playingFilePath: String?,
    onGenerateAllBackground: () -> Unit,
    onMergeAndPlayMasterWav: () -> Unit,
    onExportSrtClick: () -> Unit,
    onPlayOrStopMaster: (String) -> Unit
) {
    val srtPreview = WavAudioEngine.generateSrtSubtitles(cards)
    val synthesizedCount = cards.count { it.wavFilePath != null }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("master_merger_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.45f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Full Story Audio Merger & .SRT Studio",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Concatenates all 24kHz 16-bit Mono dialogue buffers with exact pauseAfter silence gaps into a single Master .WAV file.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Stats summary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = StudioSurfaceElevated,
                            border = BorderStroke(1.dp, StudioGlassBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("DIALOGUE CARDS", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(
                                    "$synthesizedCount / ${cards.size} Ready",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NeonCyan
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = StudioSurfaceElevated,
                            border = BorderStroke(1.dp, StudioGlassBorder)
                        ) {
                            val totalPauseSec = cards.sumOf { it.pauseAfter.toDouble() }
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("SILENCE GAPS", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(
                                    String.format(Locale.US, "%.1f sec total", totalPauseSec),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = WarmAmber
                                )
                            }
                        }
                    }

                    if (isBatchGenerating) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Synthesizing Story in Background: $batchCompleted / $batchTotal cards...",
                            style = MaterialTheme.typography.labelLarge,
                            color = NeonCyan
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = {
                                if (batchTotal > 0) batchCompleted.toFloat() / batchTotal.toFloat() else 0f
                            },
                            modifier = Modifier.fillMaxWidth(),
                            color = NeonCyan,
                            trackColor = StudioSurfaceElevated
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onGenerateAllBackground,
                        enabled = !isBatchGenerating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("batch_generate_story_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricViolet,
                            contentColor = Color(0xFF150433)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.AudioFile, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generate Full Story in Background", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onMergeAndPlayMasterWav,
                        enabled = !isBatchGenerating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("merge_master_wav_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldMint,
                            contentColor = Color(0xFF002411)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.MergeType, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Merge All & Play Master .WAV", fontWeight = FontWeight.Bold)
                    }

                    if (mergedMasterWavPath != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val isPlayingMaster = playingFilePath == mergedMasterWavPath
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = StudioSurfaceElevated,
                            border = BorderStroke(1.dp, EmeraldMint)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Master Story .WAV Ready",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = EmeraldMint
                                    )
                                    Text(
                                        text = String.format(
                                            Locale.US,
                                            "24kHz 16-bit Mono • Total Duration: %.1fs",
                                            mergedMasterDurationMs / 1000f
                                        ),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                                Button(
                                    onClick = { onPlayOrStopMaster(mergedMasterWavPath) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonCyan,
                                        contentColor = Color(0xFF00222B)
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (isPlayingMaster) Icons.Default.Stop else Icons.Default.PlayArrow,
                                        contentDescription = null
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isPlayingMaster) "Stop" else "Play Master")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onExportSrtClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("export_srt_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, NeonCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClosedCaption,
                            contentDescription = null,
                            tint = NeonCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Export .SRT Subtitles for Reels/CapCut", color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                border = BorderStroke(1.dp, StudioGlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "LIVE .SRT SUBTITLE TIMELINE PREVIEW",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonCyan
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = StudioSurfaceElevated,
                        border = BorderStroke(1.dp, StudioGlassBorder)
                    ) {
                        Text(
                            text = srtPreview,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceHistoryScreen(
    historyClips: List<VoiceClipEntity>,
    playingFilePath: String?,
    onPlayClip: (String) -> Unit,
    onLoadAndReEdit: (VoiceClipEntity) -> Unit,
    onDeleteClip: (VoiceClipEntity) -> Unit,
    onClearAll: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.US)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("voice_history_screen")
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Voice History & Re-Editor",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = "${historyClips.size} saved clips in local database",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
            if (historyClips.isNotEmpty()) {
                TextButton(
                    onClick = onClearAll,
                    modifier = Modifier.testTag("clear_history_button")
                ) {
                    Text("Clear All", color = DramaticCoral)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (historyClips.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                border = BorderStroke(1.dp, StudioGlassBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No Voice Clips Saved Yet",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Generate any dialogue card or run a 2s Micro-Preview in the Studio tab. Every clip is automatically archived here for playback and Re-Editing.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(historyClips, key = { it.id }) { clip ->
                    val presetColor = Color(
                        CHARACTER_PRESETS.find { it.key == clip.charKey }?.badgeColorHex ?: 0xFF00E5FF
                    )
                    val isPlaying = playingFilePath == clip.wavFilePath

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("history_clip_card_${clip.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = StudioSurface),
                        border = BorderStroke(1.dp, StudioGlassBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = presetColor.copy(alpha = 0.18f),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, presetColor)
                                ) {
                                    Text(
                                        text = "${clip.characterLabel} • ${clip.voice}" +
                                            if (clip.isMicroPreview) " (2s Preview)" else "",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = presetColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Text(
                                    text = dateFormat.format(Date(clip.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = clip.text,
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextPrimary
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Acting Direction: ${clip.emotion}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricViolet
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { onPlayClip(clip.wavFilePath) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = NeonCyan,
                                            contentColor = Color(0xFF00222B)
                                        ),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("history_play_button_${clip.id}")
                                    ) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isPlaying) "Stop" else String.format(
                                                Locale.US,
                                                "Play (%.1fs)",
                                                clip.durationMs / 1000f
                                            ),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = { onLoadAndReEdit(clip) },
                                        border = BorderStroke(1.dp, EmeraldMint),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("history_reedit_button_${clip.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.EditNote,
                                            contentDescription = null,
                                            tint = EmeraldMint,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Load & Re-Edit",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = EmeraldMint
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { onDeleteClip(clip) },
                                    modifier = Modifier.testTag("history_delete_button_${clip.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete Clip",
                                        tint = DramaticCoral
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
