package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CHARACTER_PRESETS
import com.example.data.model.DialogueCard
import com.example.data.model.QUICK_EMOTION_CHIPS
import com.example.data.model.VOICE_MODELS
import com.example.ui.theme.DramaticCoral
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.StudioGlassBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmAmber
import java.util.Locale

@Composable
fun ActingDirectorScriptCard(
    scriptInput: String,
    isAnalyzing: Boolean,
    onScriptChange: (String) -> Unit,
    onAnalyzeClick: () -> Unit,
    onResetSampleClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("acting_director_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        border = BorderStroke(1.dp, StudioGlassBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "STAGE 1 • AI Acting Director",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Auto Script Breakdown, Character Preset & Emotion Tagging",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                TextButton(
                    onClick = onResetSampleClick,
                    modifier = Modifier.testTag("reset_sample_script_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = null,
                        tint = WarmAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sample", color = WarmAmber, style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = scriptInput,
                onValueChange = onScriptChange,
                label = { Text("Bengali Emotional Story / Script") },
                minLines = 4,
                maxLines = 8,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bengali_script_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = StudioGlassBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onAnalyzeClick,
                enabled = !isAnalyzing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("analyze_script_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = Color(0xFF00222B)
                )
            ) {
                if (isAnalyzing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color(0xFF00222B),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Analyzing Characters & Emotional Cues...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Auto-Analyze Script & Emotions (JSON)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DialogueEditorCardItem(
    index: Int,
    card: DialogueCard,
    isPlayingThisCard: Boolean,
    onSelectPreset: (String) -> Unit,
    onSelectVoice: (String) -> Unit,
    onApplyEmotionChip: (String) -> Unit,
    onEmotionTextChange: (String) -> Unit,
    onPauseChange: (Float) -> Unit,
    onDialogueTextChange: (String) -> Unit,
    onMicroPreviewClick: () -> Unit,
    onOfflineDraftClick: () -> Unit,
    onGenerateVoiceClick: () -> Unit,
    onPlayOrStopWavClick: () -> Unit,
    onDeleteCardClick: () -> Unit
) {
    var showPresetDropdown by remember { mutableStateOf(false) }
    val activePreset = CHARACTER_PRESETS.find { it.key == card.charKey } ?: CHARACTER_PRESETS.first()
    val accentColor = Color(activePreset.badgeColorHex)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dialogue_card_${index + 1}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Card Number + Character & Age Preset Dropdown + Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = accentColor.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, accentColor)
                    ) {
                        Text(
                            text = "#${index + 1}",
                            style = MaterialTheme.typography.labelSmall,
                            color = accentColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box {
                        Surface(
                            modifier = Modifier
                                .clickable { showPresetDropdown = true }
                                .testTag("preset_dropdown_${card.id}"),
                            shape = RoundedCornerShape(10.dp),
                            color = StudioSurfaceElevated,
                            border = BorderStroke(1.dp, StudioGlassBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "${activePreset.label} ▾",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${activePreset.bengaliRole} • Voice: ${card.voice}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accentColor
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showPresetDropdown,
                            onDismissRequest = { showPresetDropdown = false }
                        ) {
                            CHARACTER_PRESETS.forEach { preset ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(preset.label, fontWeight = FontWeight.Bold)
                                            Text(
                                                "${preset.bengaliRole} (Default: ${preset.defaultVoice})",
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    },
                                    onClick = {
                                        onSelectPreset(preset.key)
                                        showPresetDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                IconButton(
                    onClick = onDeleteCardClick,
                    modifier = Modifier.testTag("delete_card_button_${card.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete Dialogue Card",
                        tint = DramaticCoral
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Voice Model Selector Pills (Puck, Fenrir, Kore, Aoede, Charon)
            Text(
                text = "VOICE MODEL SELECTOR",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                VOICE_MODELS.forEach { voiceName ->
                    val isSelected = card.voice == voiceName
                    Surface(
                        modifier = Modifier
                            .clickable { onSelectVoice(voiceName) }
                            .testTag("voice_chip_${card.id}_$voiceName"),
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) NeonCyan.copy(alpha = 0.22f) else StudioSurfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) NeonCyan else StudioGlassBorder
                        )
                    ) {
                        Text(
                            text = voiceName,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) NeonCyan else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Emotion Tag Chips ([😠 রাগ/Anger], [😢 অভিমান/Hurt], [😌 শান্ত/Calm], [😒 হিংসা/Jealous], [🤝 বিশ্বাস/Trust])
            Text(
                text = "QUICK EMOTION TAG CHIPS",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                QUICK_EMOTION_CHIPS.forEach { chip ->
                    val isActive = card.emotion.contains(chip.actingDirection.take(12), ignoreCase = true)
                    Surface(
                        modifier = Modifier
                            .clickable { onApplyEmotionChip(chip.actingDirection) }
                            .testTag("emotion_chip_${card.id}_${chip.id}"),
                        shape = RoundedCornerShape(50),
                        color = if (isActive) ElectricViolet.copy(alpha = 0.25f) else StudioSurfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (isActive) ElectricViolet else StudioGlassBorder
                        )
                    ) {
                        Text(
                            text = chip.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isActive) ElectricViolet else TextPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Editable Acting Direction Input Box
            OutlinedTextField(
                value = card.emotion,
                onValueChange = onEmotionTextChange,
                label = { Text("English Acting Direction & Emotion Prompt") },
                singleLine = false,
                maxLines = 2,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("emotion_input_${card.id}"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricViolet,
                    unfocusedBorderColor = StudioGlassBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Editable Bengali Dialogue Textarea
            OutlinedTextField(
                value = card.text,
                onValueChange = onDialogueTextChange,
                label = { Text("Bengali Dialogue Line (বাংলা সংলাপ)") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialogue_text_${card.id}"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = StudioGlassBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Dramatic Silence / Pause Slider (0.0s to 5.0s)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Dramatic Silence / Pause After Line",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Text(
                    text = String.format(Locale.US, "%.1f sec gap", card.pauseAfter),
                    style = MaterialTheme.typography.labelSmall,
                    color = WarmAmber,
                    fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = card.pauseAfter,
                onValueChange = onPauseChange,
                valueRange = 0f..5f,
                steps = 49,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pause_slider_${card.id}"),
                colors = SliderDefaults.colors(
                    thumbColor = WarmAmber,
                    activeTrackColor = WarmAmber,
                    inactiveTrackColor = StudioSurfaceElevated
                )
            )

            // Waveform Visualizer & Status Pill (when WAV is generated)
            if (card.wavFilePath != null && card.waveform.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = StudioSurfaceElevated,
                    border = BorderStroke(1.dp, EmeraldMint.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = card.statusLabel ?: "24kHz 16-bit Mono WAV Ready",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldMint
                            )
                            TextButton(
                                onClick = onPlayOrStopWavClick,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("play_wav_button_${card.id}")
                            ) {
                                Icon(
                                    imageVector = if (isPlayingThisCard) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isPlayingThisCard) "Stop" else "Play .WAV",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonCyan
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp)
                        ) {
                            val barCount = card.waveform.size.coerceAtLeast(1)
                            val spacing = 3.dp.toPx()
                            val totalSpacing = spacing * (barCount - 1)
                            val barWidth = ((size.width - totalSpacing) / barCount).coerceAtLeast(2f)

                            card.waveform.forEachIndexed { idx, amp ->
                                val barHeight = (amp.coerceIn(0.12f, 1.0f) * size.height)
                                val topY = (size.height - barHeight) / 2f
                                val x = idx * (barWidth + spacing)
                                drawRoundRect(
                                    color = if (isPlayingThisCard) NeonCyan else EmeraldMint,
                                    topLeft = Offset(x, topY),
                                    size = Size(barWidth, barHeight),
                                    cornerRadius = CornerRadius(4f, 4f)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dual Preview System Row: "⚡ 2s Micro-Preview" + "🔊 Instant Draft (Offline)"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onMicroPreviewClick,
                    enabled = !card.isMicroPreviewing && !card.isGenerating,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("micro_preview_button_${card.id}"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, WarmAmber),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    if (card.isMicroPreviewing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = WarmAmber,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = WarmAmber,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "⚡ 2s Micro-Preview",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmAmber
                    )
                }

                OutlinedButton(
                    onClick = onOfflineDraftClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("offline_draft_button_${card.id}"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ElectricViolet),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = ElectricViolet,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "🔊 Instant Draft",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricViolet
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Full Card Voice Generation Button
            Button(
                onClick = onGenerateVoiceClick,
                enabled = !card.isGenerating && !card.isMicroPreviewing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("generate_voice_button_${card.id}"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color(0xFF0A0E17)
                )
            ) {
                if (card.isGenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color(0xFF0A0E17),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Synthesizing 24kHz Emotional WAV...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (card.wavFilePath != null) "Regenerate Full Line (.WAV)" else "Generate Full Voice (.WAV)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
