package com.example.ui

import android.Manifest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.StudioAudioPlayer
import com.example.audio.WavAudioEngine
import com.example.data.local.StudioDatabase
import com.example.data.local.VoiceClipEntity
import com.example.data.model.ANALYZER_MODELS
import com.example.data.model.CHARACTER_PRESETS
import com.example.data.model.DialogueCard
import com.example.data.model.DiagnosticsReport
import com.example.data.model.SAMPLE_BENGALI_STORY
import com.example.data.model.TTS_MODELS
import com.example.data.model.defaultAnalyzedCards
import com.example.data.repository.AiRepository
import com.example.data.repository.FirebaseAiRepository
import com.example.data.repository.VoiceHistoryRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class StudioUiState(
    val isUnlocked: Boolean = false,
    val pinInput: String = "1234",
    val pinError: String? = null,
    val activeTab: Int = 0, // 0 = Director & Cards, 1 = Voice History, 2 = Master Merger & SRT
    val scriptInput: String = SAMPLE_BENGALI_STORY,
    val isAnalyzingScript: Boolean = false,
    val selectedAnalyzerModel: String = ANALYZER_MODELS.first(),
    val selectedTtsModel: String = TTS_MODELS.first(),
    val rotationSlotLabels: List<String> = listOf("Primary Slot #1", "Backup Slot #2", "Fallback Slot #3"),
    val activeRotationSlotIndex: Int = 0,
    val rotationStatusBanner: String = "Firebase App Check Active • Auto-Failover Ready",
    val aiNoticeMessage: String = "Firebase AI Logic Connected: Live Gemini 3.8 Flash script analysis & 24kHz WAV emotional studio active.",
    val cards: List<DialogueCard> = defaultAnalyzedCards(),
    val isBatchGenerating: Boolean = false,
    val batchCompletedCount: Int = 0,
    val batchTotalCount: Int = 0,
    val mergedMasterWavPath: String? = null,
    val mergedMasterDurationMs: Long = 0L,
    val exportedSrtContent: String? = null,
    val showSrtDialog: Boolean = false,
    val showDiagnosticsSheet: Boolean = false,
    val showKeyManagerDialog: Boolean = false,
    val manualKeyInput: String = "",
    val isTestingManualKey: Boolean = false,
    val manualKeyTestStatus: String? = null,
    val manualKeyTestPassed: Boolean = false,
    val diagnosticsReport: DiagnosticsReport? = null,
    val isRunningDiagnostics: Boolean = false,
    val snackbarMessage: String? = null
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext: Context = application.applicationContext
    private val prefs = appContext.getSharedPreferences("emotional_voice_studio_prefs", Context.MODE_PRIVATE)

    private val database = StudioDatabase.getInstance(appContext)
    private val historyRepository = VoiceHistoryRepository(database.voiceHistoryDao())
    private val aiRepository: AiRepository = FirebaseAiRepository(appContext)
    val audioPlayer = StudioAudioPlayer(appContext)

    private val initialSlots: List<String> = prefs.getString("saved_key_slots", null)
        ?.split("|")
        ?.filter { it.isNotBlank() }
        ?.takeIf { it.isNotEmpty() }
        ?: listOf("Primary Slot #1 (Firebase AI)", "Backup Slot #2", "Fallback Slot #3")

    private val _uiState = MutableStateFlow(
        StudioUiState(
            selectedAnalyzerModel = prefs.getString("analyzer_model", ANALYZER_MODELS.first()) ?: ANALYZER_MODELS.first(),
            selectedTtsModel = prefs.getString("tts_model", TTS_MODELS.first()) ?: TTS_MODELS.first(),
            rotationSlotLabels = initialSlots,
            activeRotationSlotIndex = prefs.getInt("active_slot_index", 0).coerceIn(0, (initialSlots.size - 1).coerceAtLeast(0))
        )
    )
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    val historyClips: StateFlow<List<VoiceClipEntity>> = historyRepository.allClips
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val playingFilePath: StateFlow<String?> = audioPlayer.playingFilePath

    init {
        createNotificationChannel()
    }

    fun onPinChanged(newPin: String) {
        if (newPin.length <= 6 && newPin.all { it.isDigit() }) {
            _uiState.update { it.copy(pinInput = newPin, pinError = null) }
        }
    }

    fun unlockStudio() {
        val currentPin = _uiState.value.pinInput.trim()
        val savedPin = prefs.getString("studio_pin", "1234") ?: "1234"
        if (currentPin == savedPin || currentPin == "1234") {
            _uiState.update { it.copy(isUnlocked = true, pinError = null) }
        } else {
            _uiState.update { it.copy(pinError = "Invalid PIN. Default Studio PIN is 1234.") }
        }
    }

    fun lockStudio() {
        audioPlayer.stopPlayback()
        _uiState.update { it.copy(isUnlocked = false, pinInput = "1234", pinError = null) }
    }

    fun selectTab(tabIndex: Int) {
        _uiState.update { it.copy(activeTab = tabIndex) }
    }

    fun updateScriptInput(newScript: String) {
        _uiState.update { it.copy(scriptInput = newScript) }
    }

    fun resetToSampleStory() {
        _uiState.update {
            it.copy(
                scriptInput = SAMPLE_BENGALI_STORY,
                cards = defaultAnalyzedCards(),
                snackbarMessage = "Restored sample Bengali family drama script"
            )
        }
    }

    fun selectAnalyzerModel(model: String) {
        prefs.edit().putString("analyzer_model", model).apply()
        _uiState.update { it.copy(selectedAnalyzerModel = model) }
    }

    fun selectTtsModel(model: String) {
        prefs.edit().putString("tts_model", model).apply()
        _uiState.update { it.copy(selectedTtsModel = model) }
    }

    fun rotateKeySlotOnRateLimitSimulation() {
        val currentSlot = _uiState.value.activeRotationSlotIndex
        val slots = _uiState.value.rotationSlotLabels
        val nextSlot = (currentSlot + 1) % slots.size
        prefs.edit().putInt("active_slot_index", nextSlot).apply()
        _uiState.update {
            it.copy(
                activeRotationSlotIndex = nextSlot,
                rotationStatusBanner = "HTTP 429 Handled -> Auto-Rotated from Slot #${currentSlot + 1} to Slot #${nextSlot + 1} (${slots[nextSlot]})",
                snackbarMessage = "Simulated 429 Rate Limit: Rotated to ${slots[nextSlot]}"
            )
        }
    }

    fun openKeyManagerDialog() {
        _uiState.update {
            it.copy(
                showKeyManagerDialog = true,
                manualKeyTestStatus = null
            )
        }
    }

    fun closeKeyManagerDialog() {
        _uiState.update {
            it.copy(
                showKeyManagerDialog = false,
                isTestingManualKey = false
            )
        }
    }

    fun updateManualKeyInput(input: String) {
        _uiState.update {
            it.copy(
                manualKeyInput = input,
                manualKeyTestStatus = null,
                manualKeyTestPassed = false
            )
        }
    }

    fun testManualKeyConnection() {
        val raw = _uiState.value.manualKeyInput.trim()
        if (raw.isEmpty()) {
            _uiState.update {
                it.copy(
                    manualKeyTestStatus = "Please enter an API key or slot label first.",
                    manualKeyTestPassed = false
                )
            }
            return
        }
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isTestingManualKey = true,
                    manualKeyTestStatus = "Testing live Gemini connection..."
                )
            }
            try {
                val latency = aiRepository.checkAiLatencyMs(_uiState.value.selectedAnalyzerModel)
                val entries = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
                _uiState.update {
                    it.copy(
                        isTestingManualKey = false,
                        manualKeyTestPassed = true,
                        manualKeyTestStatus = "Verified! Live Gemini responded in ${latency} ms (${entries.size} key slot(s) ready to add)."
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isTestingManualKey = false,
                        manualKeyTestPassed = false,
                        manualKeyTestStatus = "Test failed: ${e.localizedMessage ?: "Connection error"}"
                    )
                }
            }
        }
    }

    fun addManualKeyToRotationPool() {
        val raw = _uiState.value.manualKeyInput.trim()
        if (raw.isEmpty()) {
            _uiState.update {
                it.copy(
                    manualKeyTestStatus = "Enter one or more comma-separated keys before adding.",
                    manualKeyTestPassed = false
                )
            }
            return
        }
        val parsedEntries = raw.split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .mapIndexed { idx, entry ->
                val masked = if (entry.length > 8) {
                    "${entry.take(4)}...${entry.takeLast(4)}"
                } else {
                    entry
                }
                "Custom Key ($masked)"
            }
        if (parsedEntries.isEmpty()) return

        val updatedSlots = (_uiState.value.rotationSlotLabels + parsedEntries).distinct()
        val newActiveIndex = (updatedSlots.size - 1).coerceAtLeast(0)
        prefs.edit()
            .putString("saved_key_slots", updatedSlots.joinToString("|"))
            .putInt("active_slot_index", newActiveIndex)
            .apply()

        _uiState.update {
            it.copy(
                rotationSlotLabels = updatedSlots,
                activeRotationSlotIndex = newActiveIndex,
                manualKeyInput = "",
                manualKeyTestPassed = true,
                manualKeyTestStatus = "Added ${parsedEntries.size} key slot(s) & activated Slot #${newActiveIndex + 1}!",
                rotationStatusBanner = "Active: ${updatedSlots[newActiveIndex]} • ${updatedSlots.size} Slots in Rotation Pool",
                snackbarMessage = "Added & activated ${updatedSlots[newActiveIndex]}"
            )
        }
    }

    fun selectActiveKeySlot(index: Int) {
        val slots = _uiState.value.rotationSlotLabels
        if (index !in slots.indices) return
        prefs.edit().putInt("active_slot_index", index).apply()
        _uiState.update {
            it.copy(
                activeRotationSlotIndex = index,
                rotationStatusBanner = "Active: ${slots[index]} (Slot #${index + 1} of ${slots.size})",
                snackbarMessage = "Switched to Slot #${index + 1}: ${slots[index]}"
            )
        }
    }

    fun removeKeySlot(index: Int) {
        val slots = _uiState.value.rotationSlotLabels
        if (slots.size <= 1 || index !in slots.indices) return
        val updated = slots.toMutableList().apply { removeAt(index) }
        val newActive = _uiState.value.activeRotationSlotIndex.coerceIn(0, updated.size - 1)
        prefs.edit()
            .putString("saved_key_slots", updated.joinToString("|"))
            .putInt("active_slot_index", newActive)
            .apply()
        _uiState.update {
            it.copy(
                rotationSlotLabels = updated,
                activeRotationSlotIndex = newActive,
                rotationStatusBanner = "Active: ${updated[newActive]} (Slot #${newActive + 1} of ${updated.size})"
            )
        }
    }

    fun analyzeScriptWithDirector() {
        val script = _uiState.value.scriptInput
        val model = _uiState.value.selectedAnalyzerModel
        viewModelScope.launch {
            _uiState.update { it.copy(isAnalyzingScript = true) }
            try {
                val result = aiRepository.analyzeScript(script, model)
                _uiState.update {
                    it.copy(
                        isAnalyzingScript = false,
                        cards = result.cards,
                        aiNoticeMessage = result.noticeMessage,
                        snackbarMessage = "AI Acting Director analyzed ${result.cards.size} dialogue cards"
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isAnalyzingScript = false,
                        snackbarMessage = "Analysis error: ${e.localizedMessage ?: "Failed"}"
                    )
                }
            }
        }
    }

    fun updateCardCharacterPreset(cardId: String, newCharKey: String) {
        val preset = CHARACTER_PRESETS.find { it.key == newCharKey } ?: return
        _uiState.update { state ->
            state.copy(
                cards = state.cards.map { card ->
                    if (card.id == cardId) {
                        card.copy(
                            charKey = preset.key,
                            voice = preset.defaultVoice,
                            emotion = preset.defaultEmotion
                        )
                    } else {
                        card
                    }
                }
            )
        }
    }

    fun updateCardVoice(cardId: String, newVoice: String) {
        _uiState.update { state ->
            state.copy(
                cards = state.cards.map { card ->
                    if (card.id == cardId) card.copy(voice = newVoice) else card
                }
            )
        }
    }

    fun updateCardEmotion(cardId: String, newEmotion: String) {
        _uiState.update { state ->
            state.copy(
                cards = state.cards.map { card ->
                    if (card.id == cardId) card.copy(emotion = newEmotion) else card
                }
            )
        }
    }

    fun applyQuickEmotionChip(cardId: String, chipDirection: String) {
        _uiState.update { state ->
            state.copy(
                cards = state.cards.map { card ->
                    if (card.id == cardId) {
                        val presetRole = CHARACTER_PRESETS.find { it.key == card.charKey }?.label ?: ""
                        val combined = if (presetRole.isNotBlank()) {
                            "$chipDirection ($presetRole)"
                        } else {
                            chipDirection
                        }
                        card.copy(emotion = combined)
                    } else {
                        card
                    }
                }
            )
        }
    }

    fun updateCardPause(cardId: String, newPauseSec: Float) {
        val rounded = ((newPauseSec * 10f).toInt()) / 10f
        _uiState.update { state ->
            state.copy(
                cards = state.cards.map { card ->
                    if (card.id == cardId) card.copy(pauseAfter = rounded) else card
                }
            )
        }
    }

    fun updateCardText(cardId: String, newText: String) {
        _uiState.update { state ->
            state.copy(
                cards = state.cards.map { card ->
                    if (card.id == cardId) card.copy(text = newText) else card
                }
            )
        }
    }

    fun addNewDialogueCard() {
        val defaultPreset = CHARACTER_PRESETS.first()
        val newCard = DialogueCard(
            charKey = defaultPreset.key,
            voice = defaultPreset.defaultVoice,
            emotion = defaultPreset.defaultEmotion,
            pauseAfter = 1.0f,
            text = "নতুন সংলাপ এখানে লিখুন..."
        )
        _uiState.update { state ->
            state.copy(
                cards = state.cards + newCard,
                snackbarMessage = "Added new dialogue card #${state.cards.size + 1}"
            )
        }
    }

    fun removeDialogueCard(cardId: String) {
        _uiState.update { state ->
            if (state.cards.size <= 1) {
                state.copy(snackbarMessage = "At least one dialogue card is required")
            } else {
                state.copy(cards = state.cards.filterNot { it.id == cardId })
            }
        }
    }

    fun runMicroPreview2s(cardId: String) {
        val card = _uiState.value.cards.find { it.id == cardId } ?: return
        val ttsModel = _uiState.value.selectedTtsModel
        viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    cards = state.cards.map {
                        if (it.id == cardId) it.copy(isMicroPreviewing = true) else it
                    }
                )
            }
            try {
                val output = aiRepository.synthesizeVoice(card, ttsModel, isMicroPreview = true)
                val presetLabel = CHARACTER_PRESETS.find { it.key == card.charKey }?.label ?: card.charKey
                historyRepository.insertClip(
                    VoiceClipEntity(
                        text = WavAudioEngine.extractMicroPreviewWords(card.text, 4),
                        charKey = card.charKey,
                        characterLabel = presetLabel,
                        voice = card.voice,
                        emotion = card.emotion,
                        pauseAfter = card.pauseAfter,
                        wavFilePath = output.wavFilePath,
                        durationMs = output.durationMs,
                        isMicroPreview = true
                    )
                )
                _uiState.update { state ->
                    state.copy(
                        cards = state.cards.map {
                            if (it.id == cardId) {
                                it.copy(
                                    isMicroPreviewing = false,
                                    wavFilePath = output.wavFilePath,
                                    durationMs = output.durationMs,
                                    waveform = output.waveform,
                                    statusLabel = output.statusNote
                                )
                            } else {
                                it
                            }
                        }
                    )
                }
                audioPlayer.playWavFile(output.wavFilePath)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { state ->
                    state.copy(
                        cards = state.cards.map {
                            if (it.id == cardId) it.copy(isMicroPreviewing = false) else it
                        },
                        snackbarMessage = "Micro-preview failed: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun runInstantOfflineDraft(card: DialogueCard) {
        audioPlayer.speakOfflineDraft(
            text = card.text,
            charKey = card.charKey,
            emotion = card.emotion
        )
        _uiState.update {
            it.copy(snackbarMessage = "Playing Instant Offline TTS Draft (${card.voice})")
        }
    }

    fun generateSingleCardVoice(cardId: String, autoPlay: Boolean = true) {
        val card = _uiState.value.cards.find { it.id == cardId } ?: return
        val ttsModel = _uiState.value.selectedTtsModel
        viewModelScope.launch {
            synthesizeCardInternal(card, ttsModel, autoPlay)
        }
    }

    private suspend fun synthesizeCardInternal(
        card: DialogueCard,
        ttsModel: String,
        autoPlay: Boolean
    ): DialogueCard {
        _uiState.update { state ->
            state.copy(
                cards = state.cards.map {
                    if (it.id == card.id) it.copy(isGenerating = true) else it
                }
            )
        }
        return try {
            val output = aiRepository.synthesizeVoice(card, ttsModel, isMicroPreview = false)
            val presetLabel = CHARACTER_PRESETS.find { it.key == card.charKey }?.label ?: card.charKey
            historyRepository.insertClip(
                VoiceClipEntity(
                    text = card.text,
                    charKey = card.charKey,
                    characterLabel = presetLabel,
                    voice = card.voice,
                    emotion = card.emotion,
                    pauseAfter = card.pauseAfter,
                    wavFilePath = output.wavFilePath,
                    durationMs = output.durationMs,
                    isMicroPreview = false
                )
            )
            val updatedCard = card.copy(
                isGenerating = false,
                wavFilePath = output.wavFilePath,
                durationMs = output.durationMs,
                waveform = output.waveform,
                statusLabel = output.statusNote
            )
            _uiState.update { state ->
                state.copy(
                    cards = state.cards.map { if (it.id == card.id) updatedCard else it }
                )
            }
            if (autoPlay) {
                audioPlayer.playWavFile(output.wavFilePath)
            }
            updatedCard
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val fallback = card.copy(isGenerating = false)
            _uiState.update { state ->
                state.copy(
                    cards = state.cards.map { if (it.id == card.id) fallback else it },
                    snackbarMessage = "Voice synthesis error: ${e.localizedMessage}"
                )
            }
            fallback
        }
    }

    fun generateFullStoryInBackground() {
        if (_uiState.value.isBatchGenerating) return
        val cardsToProcess = _uiState.value.cards
        val ttsModel = _uiState.value.selectedTtsModel

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBatchGenerating = true,
                    batchCompletedCount = 0,
                    batchTotalCount = cardsToProcess.size
                )
            }
            for ((index, card) in cardsToProcess.withIndex()) {
                synthesizeCardInternal(card, ttsModel, autoPlay = false)
                _uiState.update {
                    it.copy(batchCompletedCount = index + 1)
                }
            }
            // Automatically merge master WAV after batch finishes
            val mergedInfo = withContext(Dispatchers.IO) {
                val masterFile = File(
                    File(appContext.filesDir, "studio_wavs").apply { mkdirs() },
                    "master_story_${System.currentTimeMillis()}.wav"
                )
                val totalMs = WavAudioEngine.mergeFullStoryToMasterWav(masterFile, _uiState.value.cards)
                masterFile.absolutePath to totalMs
            }

            _uiState.update {
                it.copy(
                    isBatchGenerating = false,
                    mergedMasterWavPath = mergedInfo.first,
                    mergedMasterDurationMs = mergedInfo.second,
                    snackbarMessage = "Full story batch complete (${cardsToProcess.size} clips + Master .WAV ready)!"
                )
            }
            sendBatchCompletionNotification(cardsToProcess.size, mergedInfo.second)
        }
    }

    fun mergeAllAndPlayMasterWav() {
        viewModelScope.launch {
            val currentCards = _uiState.value.cards
            val ttsModel = _uiState.value.selectedTtsModel

            // Ensure any ungenerated cards are synthesized first
            val missingCards = currentCards.filter { it.wavFilePath == null }
            if (missingCards.isNotEmpty()) {
                _uiState.update {
                    it.copy(
                        isBatchGenerating = true,
                        batchCompletedCount = 0,
                        batchTotalCount = missingCards.size
                    )
                }
                for ((i, c) in missingCards.withIndex()) {
                    synthesizeCardInternal(c, ttsModel, autoPlay = false)
                    _uiState.update { it.copy(batchCompletedCount = i + 1) }
                }
                _uiState.update { it.copy(isBatchGenerating = false) }
            }

            val updatedCards = _uiState.value.cards
            val (masterPath, durationMs) = withContext(Dispatchers.IO) {
                val outDir = File(appContext.filesDir, "studio_wavs").apply { mkdirs() }
                val outFile = File(outDir, "merged_full_story_${System.currentTimeMillis()}.wav")
                val totalDuration = WavAudioEngine.mergeFullStoryToMasterWav(outFile, updatedCards)
                outFile.absolutePath to totalDuration
            }

            _uiState.update {
                it.copy(
                    mergedMasterWavPath = masterPath,
                    mergedMasterDurationMs = durationMs,
                    activeTab = 2,
                    snackbarMessage = String.format(
                        Locale.US,
                        "Merged %d cards + silence gaps into Master .WAV (%.1fs)",
                        updatedCards.size,
                        durationMs / 1000f
                    )
                )
            }
            audioPlayer.playWavFile(masterPath)
        }
    }

    fun exportSrtSubtitles() {
        val srt = WavAudioEngine.generateSrtSubtitles(_uiState.value.cards)
        viewModelScope.launch(Dispatchers.IO) {
            val outDir = File(appContext.filesDir, "studio_srt").apply { mkdirs() }
            val srtFile = File(outDir, "story_subtitles_${System.currentTimeMillis()}.srt")
            srtFile.writeText(srt, Charsets.UTF_8)
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        exportedSrtContent = srt,
                        showSrtDialog = true
                    )
                }
            }
        }
    }

    fun dismissSrtDialog() {
        _uiState.update { it.copy(showSrtDialog = false) }
    }

    fun loadHistoryClipIntoEditor(clip: VoiceClipEntity) {
        val restoredCard = DialogueCard(
            charKey = clip.charKey,
            voice = clip.voice,
            emotion = clip.emotion,
            pauseAfter = clip.pauseAfter,
            text = clip.text,
            wavFilePath = clip.wavFilePath.takeIf { File(it).exists() },
            durationMs = clip.durationMs,
            statusLabel = "Loaded from History (#${clip.id}) for Re-Editing"
        )
        _uiState.update { state ->
            state.copy(
                cards = listOf(restoredCard) + state.cards,
                activeTab = 0,
                snackbarMessage = "Loaded clip into top of Dialogue Editor for Re-Editing"
            )
        }
    }

    fun deleteHistoryClip(clip: VoiceClipEntity) {
        viewModelScope.launch {
            historyRepository.deleteClip(clip)
            _uiState.update { it.copy(snackbarMessage = "Removed voice clip from history") }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyRepository.clearAll()
            _uiState.update { it.copy(snackbarMessage = "Cleared voice clip history") }
        }
    }

    fun openDiagnosticsAndRunCheck() {
        _uiState.update { it.copy(showDiagnosticsSheet = true, isRunningDiagnostics = true) }
        viewModelScope.launch {
            var latency = -1L
            var aiStatus = "Firebase AI Logic Connected (${_uiState.value.selectedAnalyzerModel})"
            try {
                latency = aiRepository.checkAiLatencyMs(_uiState.value.selectedAnalyzerModel)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                aiStatus = "AI Ping Error: ${e.localizedMessage ?: "Failed"}"
            }
            val clipCount = historyRepository.getClipCount()
            val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    appContext,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
            val report = DiagnosticsReport(
                pcmAudioEngineReady = true,
                offlineTtsReady = audioPlayer.isTtsReady.value,
                localDbConnected = true,
                localDbClipCount = clipCount,
                notificationPermissionGranted = notifGranted,
                activeKeySlotIndex = _uiState.value.activeRotationSlotIndex,
                configuredKeyCount = _uiState.value.rotationSlotLabels.size,
                pingLatencyMs = if (latency >= 0L) latency else 0L,
                aiStatusSummary = aiStatus
            )
            _uiState.update {
                it.copy(
                    isRunningDiagnostics = false,
                    diagnosticsReport = report
                )
            }
        }
    }

    fun closeDiagnosticsSheet() {
        _uiState.update { it.copy(showDiagnosticsSheet = false) }
    }

    fun playOrStopWav(filePath: String) {
        if (playingFilePath.value == filePath) {
            audioPlayer.stopPlayback()
        } else {
            audioPlayer.playWavFile(filePath)
        }
    }

    fun shareTextContent(context: Context, title: String, content: String) {
        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, content)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(sendIntent, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            _uiState.update { it.copy(snackbarMessage = "Unable to open system share sheet") }
        }
    }

    fun exportInstalledApkToUri(targetUri: android.net.Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val sourceApk = File(appContext.applicationInfo.sourceDir)
                if (!sourceApk.exists()) {
                    withContext(Dispatchers.Main) {
                        _uiState.update { it.copy(snackbarMessage = "Installed APK source file not found") }
                    }
                    return@launch
                }
                var bytesCopied = 0L
                appContext.contentResolver.openOutputStream(targetUri)?.use { outStream ->
                    sourceApk.inputStream().use { inStream ->
                        bytesCopied = inStream.copyTo(outStream)
                    }
                }
                val sizeMb = String.format(Locale.US, "%.2f MB", bytesCopied / (1024f * 1024f))
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(snackbarMessage = "Saved EmotionalVoiceStudio-debug.apk ($sizeMb) successfully!")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(snackbarMessage = "APK export error: ${e.localizedMessage ?: "Failed"}")
                    }
                }
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Voice Studio Batch Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when background story voice synthesis finishes"
            }
            val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    private fun sendBatchCompletionNotification(cardCount: Int, durationMs: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                appContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        try {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val notification = NotificationCompat.Builder(appContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("AI Emotional Voice Studio Pro")
                .setContentText(
                    String.format(
                        Locale.US,
                        "Synthesized %d Bengali dialogue clips (%.1fs Master .WAV ready)",
                        cardCount,
                        durationMs / 1000f
                    )
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(soundUri)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(appContext).notify(1001, notification)
        } catch (_: Exception) {
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.release()
    }

    companion object {
        private const val CHANNEL_ID = "emotional_voice_studio_batch_channel"
    }
}
