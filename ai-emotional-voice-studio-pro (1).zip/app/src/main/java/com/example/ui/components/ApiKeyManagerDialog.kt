package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DramaticCoral
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.StudioGlassBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmAmber

@Composable
fun ApiKeyManagerDialog(
    manualKeyInput: String,
    isTestingKey: Boolean,
    testStatusMessage: String?,
    testPassed: Boolean,
    slotLabels: List<String>,
    activeSlotIndex: Int,
    onKeyInputChange: (String) -> Unit,
    onTestKeyClick: () -> Unit,
    onAddKeyClick: () -> Unit,
    onSelectSlot: (Int) -> Unit,
    onRemoveSlot: (Int) -> Unit,
    onSimulate429Rotate: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurface,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "API Key Input, Test & Rotation Pool",
                    style = MaterialTheme.typography.titleLarge
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Enter one or more comma-separated API keys or slot labels below. Tap 'Test Connection' to verify live Gemini response latency, then tap 'Add & Activate' to save to the Multi-Key Rotation Pool.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                OutlinedTextField(
                    value = manualKeyInput,
                    onValueChange = onKeyInputChange,
                    label = { Text("Paste Gemini API Key(s) (comma-separated)") },
                    placeholder = { Text("AIzaSy...Key1, AIzaSy...Key2") },
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manual_api_key_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = StudioGlassBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Test & Add Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onTestKeyClick,
                        enabled = !isTestingKey,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("test_manual_key_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, WarmAmber),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        if (isTestingKey) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = WarmAmber,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = WarmAmber,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Test Key",
                            style = MaterialTheme.typography.labelLarge,
                            color = WarmAmber
                        )
                    }

                    Button(
                        onClick = onAddKeyClick,
                        enabled = !isTestingKey,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("add_manual_key_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCyan,
                            contentColor = Color(0xFF00222B)
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircleOutline,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Test & Add Key",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Live Test Status Banner
                if (!testStatusMessage.isNullOrBlank()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("manual_key_test_status"),
                        shape = RoundedCornerShape(10.dp),
                        color = if (testPassed) EmeraldMint.copy(alpha = 0.14f) else WarmAmber.copy(alpha = 0.14f),
                        border = BorderStroke(
                            1.dp,
                            if (testPassed) EmeraldMint else WarmAmber
                        )
                    ) {
                        Text(
                            text = testStatusMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (testPassed) EmeraldMint else WarmAmber,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Rotation Pool Header + Simulate 429 Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SAVED ROTATION SLOTS (${slotLabels.size})",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricViolet,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(
                        onClick = onSimulate429Rotate,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SyncAlt,
                            contentDescription = null,
                            tint = WarmAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Rotate (429 Test)",
                            style = MaterialTheme.typography.labelSmall,
                            color = WarmAmber
                        )
                    }
                }

                slotLabels.forEachIndexed { idx, label ->
                    val isActive = idx == activeSlotIndex
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectSlot(idx) }
                            .testTag("key_slot_item_$idx"),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isActive) NeonCyan.copy(alpha = 0.15f) else StudioSurfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (isActive) NeonCyan else StudioGlassBorder
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (isActive) EmeraldMint else TextSecondary.copy(alpha = 0.4f),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Slot #${idx + 1}: $label",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (isActive) NeonCyan else TextPrimary
                                    )
                                    Text(
                                        text = if (isActive) "ACTIVE PRIMARY SLOT" else "Tap to activate slot",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isActive) EmeraldMint else TextSecondary
                                    )
                                }
                            }

                            if (slotLabels.size > 1) {
                                IconButton(
                                    onClick = { onRemoveSlot(idx) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Remove Key Slot",
                                        tint = DramaticCoral,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
        }
    )
}
