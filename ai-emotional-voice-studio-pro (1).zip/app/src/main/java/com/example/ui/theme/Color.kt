package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioObsidian = Color(0xFF070A12)
val StudioSurface = Color(0xFF101626)
val StudioSurfaceElevated = Color(0xFF182036)
val StudioGlassBorder = Color(0xFF283556)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDim = Color(0xFF004D5A)
val ElectricViolet = Color(0xFFB388FF)
val ElectricVioletDim = Color(0xFF321E59)
val DramaticCoral = Color(0xFFFF5252)
val WarmAmber = Color(0xFFFFAB40)
val EmeraldMint = Color(0xFF00E676)

val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFFA0AEC0)
val TextMuted = Color(0xFF64748B)
