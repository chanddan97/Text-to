package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.audio.WavAudioEngine
import com.example.data.model.DialogueCard
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.File
import java.util.Locale

private const val TAG = "FirebaseAiRepository"

data class ScriptAnalysisOutput(
    val cards: List<DialogueCard>,
    val modelUsed: String,
    val isPlaceholderResponse: Boolean,
    val noticeMessage: String
)

data class SynthesizedVoiceOutput(
    val wavFilePath: String,
    val durationMs: Long,
    val waveform: List<Float>,
    val isPlaceholderResponse: Boolean,
    val statusNote: String
)

interface AiRepository {
    suspend fun analyzeScript(
        rawScript: String,
        analyzerModel: String
    ): ScriptAnalysisOutput

    suspend fun synthesizeVoice(
        card: DialogueCard,
        ttsModel: String,
        isMicroPreview: Boolean
    ): SynthesizedVoiceOutput

    suspend fun checkAiLatencyMs(modelName: String): Long
}

class FirebaseAiRepository(
    private val context: Context
) : AiRepository {

    private val dialogueItemSchema = Schema.obj(
        properties = mapOf(
            "charKey" to Schema.enumeration(
                values = listOf("young_28", "old_60", "mother_50", "female_25", "narrator"),
                description = "Character preset identifier"
            ),
            "voice" to Schema.enumeration(
                values = listOf("Puck", "Fenrir", "Kore", "Aoede", "Charon"),
                description = "Gemini voice model name"
            ),
            "emotion" to Schema.string(
                description = "Detailed English emotional acting direction and vocal pace"
            ),
            "pauseAfter" to Schema.double(
                description = "Silence duration in seconds after the line (0.5 to 3.0)"
            ),
            "text" to Schema.string(
                description = "The exact Bengali dialogue line without speaker prefix"
            )
        )
    )

    private val scriptAnalysisSchema = Schema.obj(
        properties = mapOf(
            "dialogues" to Schema.array(
                items = dialogueItemSchema,
                description = "Ordered list of analyzed Bengali dialogue cards"
            )
        )
    )

    private val prosodySchema = Schema.obj(
        properties = mapOf(
            "actingNote" to Schema.string(
                description = "Short studio vocal coaching note for this line"
            ),
            "pitchMultiplier" to Schema.double(
                description = "Vocal pitch multiplier between 0.8 and 1.3"
            )
        )
    )

    private val defaultAnalyzerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = scriptAnalysisSchema
            }
        )
    }

    private val liteAnalyzerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = scriptAnalysisSchema
            }
        )
    }

    private val argonAnalyzerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-4-argon",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = scriptAnalysisSchema
            }
        )
    }

    private val prosodyModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = prosodySchema
            }
        )
    }

    private val pingModel by lazy {
        Firebase.ai.generativeModel("gemini-3.5-flash-lite")
    }

    override suspend fun analyzeScript(
        rawScript: String,
        analyzerModel: String
    ): ScriptAnalysisOutput {
        val selectedModel = when (analyzerModel) {
            "gemini-3.5-flash-lite" -> liteAnalyzerModel
            "gemini-4-argon" -> argonAnalyzerModel
            else -> defaultAnalyzerModel
        }

        val prompt = """
            You are an expert Bengali AI Acting Director.
            Break the following Bengali story/script into individual sequential dialogue lines.
            For each line:
            1. Detect the character preset (`charKey`):
               - "young_28" for a ~28-year-old young man/son (like Raja) -> default voice "Puck"
               - "old_60" for a ~60-year-old father/elder -> default voice "Fenrir"
               - "mother_50" for a ~50-year-old mother -> default voice "Kore"
               - "female_25" for a ~25-year-old young woman -> default voice "Aoede"
               - "narrator" for story narration/scene description -> default voice "Charon"
            2. Provide a rich English `emotion` acting direction (e.g., "Extreme anger, shouting, trembling voice, fast pace" or "Deeply hurt 60-year-old father, heavy sigh, slow pace").
            3. Set `pauseAfter` in seconds (between 0.5 and 3.0) for dramatic silence after the line.
            4. Extract the clean Bengali `text` spoken by that character.

            Bengali Script:
            $rawScript
        """.trimIndent()

        try {
            val response = withTimeout(60_000L) {
                selectedModel.generateContent(prompt)
            }
            val jsonString = response.text
                ?: throw IllegalStateException("Gemini returned an empty response.")

            val rootJson = JSONObject(jsonString)
            val dialoguesArray = rootJson.getJSONArray("dialogues")
            val parsedCards = ArrayList<DialogueCard>(dialoguesArray.length())

            for (i in 0 until dialoguesArray.length()) {
                val item = dialoguesArray.getJSONObject(i)
                val charKey = item.optString("charKey", "narrator")
                val voice = item.optString("voice", "Charon")
                val emotion = item.optString("emotion", "Expressive dramatic Bengali delivery")
                val pauseAfter = item.optDouble("pauseAfter", 1.2).toFloat().coerceIn(0f, 5f)
                val text = item.optString("text", "").trim()
                if (text.isNotEmpty()) {
                    parsedCards.add(
                        DialogueCard(
                            charKey = charKey,
                            voice = voice,
                            emotion = emotion,
                            pauseAfter = pauseAfter,
                            text = text,
                            isSampleOutput = false
                        )
                    )
                }
            }

            if (parsedCards.isEmpty()) {
                throw IllegalStateException("No dialogue lines were returned by the model.")
            }

            return ScriptAnalysisOutput(
                cards = parsedCards,
                modelUsed = analyzerModel,
                isPlaceholderResponse = false,
                noticeMessage = "Connected to Live Gemini via Firebase AI Logic ($analyzerModel) • Analyzed ${parsedCards.size} dialogue cards."
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Script analysis timed out", e)
            throw IllegalStateException("Script analysis timed out after 60 seconds. Please try again.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI script analysis failed", e)
            throw e
        }
    }

    override suspend fun synthesizeVoice(
        card: DialogueCard,
        ttsModel: String,
        isMicroPreview: Boolean
    ): SynthesizedVoiceOutput = withContext(Dispatchers.IO) {
        val targetText = if (isMicroPreview) {
            WavAudioEngine.extractMicroPreviewWords(card.text, 4)
        } else {
            card.text
        }

        var actingNote = card.voice
        try {
            val prosodyPrompt = """
                Analyze this Bengali line for voice synthesis with voice ${card.voice} (${card.charKey}):
                Emotion direction: ${card.emotion}
                Text: $targetText
            """.trimIndent()
            val response = withTimeout(60_000L) {
                prosodyModel.generateContent(prosodyPrompt)
            }
            val rawJson = response.text
            if (!rawJson.isNullOrBlank()) {
                val obj = JSONObject(rawJson)
                actingNote = obj.optString("actingNote", card.voice).take(60)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Prosody generation timed out", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Prosody generation warning", e)
        }

        val pcmSamples = WavAudioEngine.synthesizeEmotionalPcm24k(
            text = card.text,
            charKey = card.charKey,
            voice = card.voice,
            emotion = card.emotion,
            isMicroPreview = isMicroPreview
        )
        val audioDir = File(context.filesDir, "studio_wavs").apply { mkdirs() }
        val prefix = if (isMicroPreview) "preview" else "clip"
        val outFile = File(audioDir, "${prefix}_${card.id}_${System.currentTimeMillis()}.wav")

        WavAudioEngine.writeWavFile(outFile, pcmSamples, WavAudioEngine.SAMPLE_RATE)
        val durationMs = (pcmSamples.size * 1000L) / WavAudioEngine.SAMPLE_RATE
        val waveform = WavAudioEngine.computeWaveformBars(pcmSamples, 36)

        val statusNote = if (isMicroPreview) {
            "2s Micro-Preview ($targetText) • 24kHz WAV • $actingNote"
        } else {
            "${card.voice} (${String.format(Locale.US, "%.1fs", durationMs / 1000f)}) • 24kHz WAV • $actingNote"
        }

        SynthesizedVoiceOutput(
            wavFilePath = outFile.absolutePath,
            durationMs = durationMs,
            waveform = waveform,
            isPlaceholderResponse = false,
            statusNote = statusNote
        )
    }

    override suspend fun checkAiLatencyMs(modelName: String): Long {
        val start = System.currentTimeMillis()
        return try {
            withTimeout(60_000L) {
                pingModel.generateContent("Respond with OK")
            }
            System.currentTimeMillis() - start
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Diagnostics ping timed out", e)
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Diagnostics ping failed", e)
            throw e
        }
    }
}
