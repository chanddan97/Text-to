package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceHistoryDao {
    @Query("SELECT * FROM voice_clips_history ORDER BY timestamp DESC")
    fun observeAllClips(): Flow<List<VoiceClipEntity>>

    @Query("SELECT COUNT(*) FROM voice_clips_history")
    suspend fun getClipCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: VoiceClipEntity): Long

    @Query("DELETE FROM voice_clips_history WHERE id = :id")
    suspend fun deleteClipById(id: Long)

    @Query("DELETE FROM voice_clips_history")
    suspend fun clearAllClips()
}
