package com.example.data.repository

import com.example.data.local.VoiceClipEntity
import com.example.data.local.VoiceHistoryDao
import kotlinx.coroutines.flow.Flow
import java.io.File

class VoiceHistoryRepository(private val dao: VoiceHistoryDao) {
    val allClips: Flow<List<VoiceClipEntity>> = dao.observeAllClips()

    suspend fun insertClip(clip: VoiceClipEntity): Long = dao.insertClip(clip)

    suspend fun getClipCount(): Int = dao.getClipCount()

    suspend fun deleteClip(clip: VoiceClipEntity) {
        try {
            val file = File(clip.wavFilePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {
        }
        dao.deleteClipById(clip.id)
    }

    suspend fun clearAll() {
        dao.clearAllClips()
    }
}
