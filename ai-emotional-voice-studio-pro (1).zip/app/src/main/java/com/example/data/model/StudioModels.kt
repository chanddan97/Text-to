package com.example.data.model

import java.util.UUID

data class CharacterPreset(
    val key: String,
    val label: String,
    val bengaliRole: String,
    val defaultVoice: String,
    val basePitchHz: Float,
    val defaultEmotion: String,
    val badgeColorHex: Long
)

val CHARACTER_PRESETS = listOf(
    CharacterPreset(
        key = "young_28",
        label = "28yr Youth (Raja)",
        bengaliRole = "২৮ বছরের যুবক (রাজা)",
        defaultVoice = "Puck",
        basePitchHz = 138f,
        defaultEmotion = "Extreme anger, shouting, trembling voice, fast pace, 28-year-old youth",
        badgeColorHex = 0xFFFF5252
    ),
    CharacterPreset(
        key = "old_60",
        label = "60yr Old Father",
        bengaliRole = "৬০ বছরের বৃদ্ধ বাবা",
        defaultVoice = "Fenrir",
        basePitchHz = 96f,
        defaultEmotion = "Deeply hurt 60-year-old father, heavy sigh, trembling breath, slow pace",
        badgeColorHex = 0xFFFFAB40
    ),
    CharacterPreset(
        key = "mother_50",
        label = "50yr Mother",
        bengaliRole = "৫০ বছরের মা",
        defaultVoice = "Kore",
        basePitchHz = 192f,
        defaultEmotion = "Emotional 50-year-old mother, tearful pleading, gentle maternal warmth",
        badgeColorHex = 0xFFB388FF
    ),
    CharacterPreset(
        key = "female_25",
        label = "25yr Young Woman",
        bengaliRole = "২৫ বছরের তরুণী",
        defaultVoice = "Aoede",
        basePitchHz = 225f,
        defaultEmotion = "Expressive 25-year-old woman, bright emotional clarity, natural cadence",
        badgeColorHex = 0xFF00E5FF
    ),
    CharacterPreset(
        key = "narrator",
        label = "Dramatic Narrator",
        bengaliRole = "গল্পের সূত্রধর (Narrator)",
        defaultVoice = "Charon",
        basePitchHz = 112f,
        defaultEmotion = "Cinematic Bengali audiobook narrator, deep resonant timbre, measured pace",
        badgeColorHex = 0xFF00E676
    )
)

val VOICE_MODELS = listOf("Puck", "Fenrir", "Kore", "Aoede", "Charon")

val ANALYZER_MODELS = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-4-argon")
val TTS_MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-3.8-flash")

data class EmotionChip(
    val id: String,
    val label: String,
    val actingDirection: String
)

val QUICK_EMOTION_CHIPS = listOf(
    EmotionChip(
        id = "anger",
        label = "😠 রাগ / Anger",
        actingDirection = "Extreme anger, shouting, trembling voice, fast pace"
    ),
    EmotionChip(
        id = "hurt",
        label = "😢 অভিমান / Hurt",
        actingDirection = "Deeply hurt, heavy sigh, choked voice, slow pace"
    ),
    EmotionChip(
        id = "calm",
        label = "😌 শান্ত / Calm",
        actingDirection = "Calm, composed, warm soothing tone, steady pace"
    ),
    EmotionChip(
        id = "jealous",
        label = "😒 হিংসা / Jealous",
        actingDirection = "Bitter jealousy, sharp accusing tone, tense delivery"
    ),
    EmotionChip(
        id = "trust",
        label = "🤝 বিশ্বাস / Trust",
        actingDirection = "Deep trust, heartfelt reassurance, sincere emotional warmth"
    )
)

data class OnboardingFeature(
    val number: Int,
    val title: String,
    val subtitle: String,
    val badge: String
)

val STUDIO_FEATURES_SHOWCASE = listOf(
    OnboardingFeature(
        number = 1,
        title = "AI Acting Director",
        subtitle = "Auto Emotion & Character Tagging from Bengali scripts with JSON schema breakdown",
        badge = "STAGE 1"
    ),
    OnboardingFeature(
        number = 2,
        title = "Multi-Age & Character Voices",
        subtitle = "28yr Youth (Puck), 60yr Father (Fenrir), 50yr Mother (Kore), 25yr Female (Aoede), Narrator (Charon)",
        badge = "5 PRESETS"
    ),
    OnboardingFeature(
        number = 3,
        title = "2s Micro-Preview & Offline TTS",
        subtitle = "Preview first 3-4 words with emotion direction or run instant zero-cost Bengali TTS draft",
        badge = "DUAL PREVIEW"
    ),
    OnboardingFeature(
        number = 4,
        title = "Background Batch & Notifications",
        subtitle = "Synthesize full multi-card stories with live progress & system completion alerts",
        badge = "BATCH ENGINE"
    ),
    OnboardingFeature(
        number = 5,
        title = "Silence Controller & WAV Merger",
        subtitle = "Precision 0s–5s dramatic pause slider + 24kHz 16-bit Mono master .WAV concatenation",
        badge = "24kHz PCM"
    ),
    OnboardingFeature(
        number = 6,
        title = "Auto .SRT Subtitle Generator",
        subtitle = "Frame-accurate .SRT subtitle export calculated from audio durations & silence gaps",
        badge = "REELS / VN"
    ),
    OnboardingFeature(
        number = 7,
        title = "Local DB History & Key Rotation",
        subtitle = "Persistent voice clip archive with one-tap Load & Re-Edit plus multi-slot failover simulation",
        badge = "ARCHIVE"
    )
)

data class DialogueCard(
    val id: String = UUID.randomUUID().toString(),
    val charKey: String,
    val voice: String,
    val emotion: String,
    val pauseAfter: Float = 1.0f,
    val text: String,
    val isGenerating: Boolean = false,
    val isMicroPreviewing: Boolean = false,
    val wavFilePath: String? = null,
    val durationMs: Long = 0L,
    val waveform: List<Float> = emptyList(),
    val isSampleOutput: Boolean = true,
    val statusLabel: String? = null
)

data class DiagnosticsReport(
    val timestamp: Long = System.currentTimeMillis(),
    val pcmAudioEngineReady: Boolean,
    val offlineTtsReady: Boolean,
    val localDbConnected: Boolean,
    val localDbClipCount: Int,
    val notificationPermissionGranted: Boolean,
    val activeKeySlotIndex: Int,
    val configuredKeyCount: Int,
    val pingLatencyMs: Long,
    val aiStatusSummary: String
)

const val SAMPLE_BENGALI_STORY = """রাত তখন প্রায় এগারোটা। পুরনো বাড়ির বারান্দায় টিমটিমে আলো জ্বলছে।
রাজা (রাগে চিৎকার করে): বাবা! আমি আর তোমার এই পুরোনো আদর্শের কথা শুনতে চাই না! আজ আমার সব বন্ধু এগিয়ে গেছে, আর আমি তোমার কথায় আটকে আছি!
বাবা (দীর্ঘশ্বাস ফেলে, অভিমানী গলায়): রাজা... তোর কাছে আমার সারা জীবনের সততা আজ বোঝা হয়ে গেল খোকা? এই বাড়িটা ইট-পাথর দিয়ে নয়, তোর বাবার রক্ত-ঘাম দিয়ে তৈরি।
মা (কাঁদো কাঁদো গলায়, আকুতি করে): থাম তোরা! রাজা, তোর বাবার বুকে ব্যথাটা আবার বাড়ছে, এভাবে কথা বলিস না বাবা... একটু শান্ত হ!
রাজা (কণ্ঠস্বর কিছুটা নামিয়ে, কিন্তু অভিমান নিয়ে): মা, তুমি সবসময় বাবার পক্ষ নাও! আমার মনের ভেতর যে ঝড়টা চলছে, সেটা কি কেউ কোনোদিন দেখতে পেয়েছ?
বাবা (শান্ত কিন্তু গভীর বিশ্বাসের সুরে): তোর ডানায় আকাশ ছোঁয়ার শক্তি আমিই দিয়েছি খোকা। যেদিন নিজের পায়ে দাঁড়াবি, সেদিন বুঝবি বাবার শাসনটা শত্রুতা ছিল না।"""

fun defaultAnalyzedCards(): List<DialogueCard> = listOf(
    DialogueCard(
        charKey = "narrator",
        voice = "Charon",
        emotion = "Cinematic Bengali audiobook narrator, atmospheric late-night tension, measured pace",
        pauseAfter = 1.2f,
        text = "রাত তখন প্রায় এগারোটা। পুরনো বাড়ির বারান্দায় টিমটিমে আলো জ্বলছে।"
    ),
    DialogueCard(
        charKey = "young_28",
        voice = "Puck",
        emotion = "Extreme anger, shouting, trembling voice, fast pace, 28-year-old frustrated son",
        pauseAfter = 1.5f,
        text = "বাবা! আমি আর তোমার এই পুরোনো আদর্শের কথা শুনতে চাই না! আজ আমার সব বন্ধু এগিয়ে গেছে, আর আমি তোমার কথায় আটকে আছি!"
    ),
    DialogueCard(
        charKey = "old_60",
        voice = "Fenrir",
        emotion = "Deeply hurt 60-year-old father, heavy sigh, choked voice, slow pace",
        pauseAfter = 1.8f,
        text = "রাজা... তোর কাছে আমার সারা জীবনের সততা আজ বোঝা হয়ে গেল খোকা? এই বাড়িটা ইট-পাথর দিয়ে নয়, তোর বাবার রক্ত-ঘাম দিয়ে তৈরি।"
    ),
    DialogueCard(
        charKey = "mother_50",
        voice = "Kore",
        emotion = "Emotional 50-year-old mother, tearful pleading, anxious trembling warmth",
        pauseAfter = 1.2f,
        text = "থাম তোরা! রাজা, তোর বাবার বুকে ব্যথাটা আবার বাড়ছে, এভাবে কথা বলিস না বাবা... একটু শান্ত হ!"
    ),
    DialogueCard(
        charKey = "young_28",
        voice = "Puck",
        emotion = "Deeply hurt and jealous, defensive trembling voice, medium-fast pace",
        pauseAfter = 1.4f,
        text = "মা, তুমি সবসময় বাবার পক্ষ নাও! আমার মনের ভেতর যে ঝড়টা চলছে, সেটা কি কেউ কোনোদিন দেখতে পেয়েছ?"
    ),
    DialogueCard(
        charKey = "old_60",
        voice = "Fenrir",
        emotion = "Calm, forgiving 60-year-old father, deep trust, warm emotional resonance, slow pace",
        pauseAfter = 2.0f,
        text = "তোর ডানায় আকাশ ছোঁয়ার শক্তি আমিই দিয়েছি খোকা। যেদিন নিজের পায়ে দাঁড়াবি, সেদিন বুঝবি বাবার শাসনটা শত্রুতা ছিল না।"
    )
)
