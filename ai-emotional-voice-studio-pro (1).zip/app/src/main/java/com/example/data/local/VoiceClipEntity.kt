package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_clips_history")
data class VoiceClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val text: String,
    val charKey: String,
    val characterLabel: String,
    val voice: String,
    val emotion: String,
    val pauseAfter: Float,
    val wavFilePath: String,
    val durationMs: Long,
    val isMicroPreview: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
