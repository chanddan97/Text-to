package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.StudioViewModel
import com.example.ui.components.ActingDirectorScriptCard
import com.example.ui.components.ApiKeyManagerDialog
import com.example.ui.components.DialogueEditorCardItem
import com.example.ui.components.DiagnosticsBottomSheet
import com.example.ui.components.MasterMergerAndSrtScreen
import com.example.ui.components.SplashOnboardingScreen
import com.example.ui.components.SrtExportDialog
import com.example.ui.components.StudioTopHeader
import com.example.ui.components.VoiceHistoryScreen
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldMint
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.StudioGlassBorder
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                EmotionalVoiceStudioApp()
            }
        }
    }
}

@Composable
fun EmotionalVoiceStudioApp(
    studioViewModel: StudioViewModel = viewModel()
) {
    val uiState by studioViewModel.uiState.collectAsStateWithLifecycle()
    val historyClips by studioViewModel.historyClips.collectAsStateWithLifecycle()
    val playingFilePath by studioViewModel.playingFilePath.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        if (uiState.showDiagnosticsSheet) {
            studioViewModel.openDiagnosticsAndRunCheck()
        }
    }

    val saveApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri ->
        if (uri != null) {
            studioViewModel.exportInstalledApkToUri(uri)
        }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        val msg = uiState.snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            studioViewModel.clearSnackbar()
        }
    }

    if (!uiState.isUnlocked) {
        SplashOnboardingScreen(
            pinInput = uiState.pinInput,
            pinError = uiState.pinError,
            onPinChange = studioViewModel::onPinChanged,
            onUnlockClick = studioViewModel::unlockStudio
        )
        return
    }

    // BackHandler for secondary tabs to return to the primary Director & Cards Studio tab
    BackHandler(enabled = uiState.activeTab != 0) {
        studioViewModel.selectTab(0)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = StudioObsidian,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            StudioTopHeader(
                selectedAnalyzerModel = uiState.selectedAnalyzerModel,
                selectedTtsModel = uiState.selectedTtsModel,
                activeSlotIndex = uiState.activeRotationSlotIndex,
                rotationBanner = uiState.rotationStatusBanner,
                aiNoticeMessage = uiState.aiNoticeMessage,
                onSelectAnalyzerModel = studioViewModel::selectAnalyzerModel,
                onSelectTtsModel = studioViewModel::selectTtsModel,
                onOpenKeyManager = studioViewModel::openKeyManagerDialog,
                onSaveDebugApk = {
                    saveApkLauncher.launch("EmotionalVoiceStudio-debug.apk")
                },
                onSimulate429Rotate = studioViewModel::rotateKeySlotOnRateLimitSimulation,
                onOpenDiagnostics = studioViewModel::openDiagnosticsAndRunCheck,
                onLockStudio = studioViewModel::lockStudio
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = StudioSurface,
                contentColor = TextPrimary
            ) {
                NavigationBarItem(
                    selected = uiState.activeTab == 0,
                    onClick = { studioViewModel.selectTab(0) },
                    icon = { Icon(Icons.Default.Mic, contentDescription = "Studio") },
                    label = { Text("Director & Cards (${uiState.cards.size})") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        indicatorColor = NeonCyan.copy(alpha = 0.16f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_studio")
                )
                NavigationBarItem(
                    selected = uiState.activeTab == 2,
                    onClick = { studioViewModel.selectTab(2) },
                    icon = { Icon(Icons.Default.MergeType, contentDescription = "Master Merger & SRT") },
                    label = { Text("Master WAV & SRT") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldMint,
                        selectedTextColor = EmeraldMint,
                        indicatorColor = EmeraldMint.copy(alpha = 0.16f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_merger")
                )
                NavigationBarItem(
                    selected = uiState.activeTab == 1,
                    onClick = { studioViewModel.selectTab(1) },
                    icon = { Icon(Icons.Default.History, contentDescription = "Voice History") },
                    label = { Text("History (${historyClips.size})") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ElectricViolet,
                        selectedTextColor = ElectricViolet,
                        indicatorColor = ElectricViolet.copy(alpha = 0.16f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_history")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(StudioObsidian),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
            ) {
                when (uiState.activeTab) {
                    0 -> DirectorAndCardsWorkspace(
                        scriptInput = uiState.scriptInput,
                        isAnalyzing = uiState.isAnalyzingScript,
                        cards = uiState.cards,
                        playingFilePath = playingFilePath,
                        isBatchGenerating = uiState.isBatchGenerating,
                        batchCompleted = uiState.batchCompletedCount,
                        batchTotal = uiState.batchTotalCount,
                        onScriptChange = studioViewModel::updateScriptInput,
                        onAnalyzeClick = studioViewModel::analyzeScriptWithDirector,
                        onResetSampleClick = studioViewModel::resetToSampleStory,
                        onSelectPreset = studioViewModel::updateCardCharacterPreset,
                        onSelectVoice = studioViewModel::updateCardVoice,
                        onApplyEmotionChip = studioViewModel::applyQuickEmotionChip,
                        onEmotionTextChange = studioViewModel::updateCardEmotion,
                        onPauseChange = studioViewModel::updateCardPause,
                        onDialogueTextChange = studioViewModel::updateCardText,
                        onMicroPreviewClick = studioViewModel::runMicroPreview2s,
                        onOfflineDraftClick = studioViewModel::runInstantOfflineDraft,
                        onGenerateVoiceClick = { cardId -> studioViewModel.generateSingleCardVoice(cardId) },
                        onPlayOrStopWavClick = studioViewModel::playOrStopWav,
                        onDeleteCardClick = studioViewModel::removeDialogueCard,
                        onAddCardClick = studioViewModel::addNewDialogueCard,
                        onBatchGenerateClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            studioViewModel.generateFullStoryInBackground()
                        },
                        onMergeMasterWavClick = studioViewModel::mergeAllAndPlayMasterWav,
                        onExportSrtClick = studioViewModel::exportSrtSubtitles
                    )

                    1 -> VoiceHistoryScreen(
                        historyClips = historyClips,
                        playingFilePath = playingFilePath,
                        onPlayClip = studioViewModel::playOrStopWav,
                        onLoadAndReEdit = studioViewModel::loadHistoryClipIntoEditor,
                        onDeleteClip = studioViewModel::deleteHistoryClip,
                        onClearAll = studioViewModel::clearAllHistory
                    )

                    2 -> MasterMergerAndSrtScreen(
                        cards = uiState.cards,
                        isBatchGenerating = uiState.isBatchGenerating,
                        batchCompleted = uiState.batchCompletedCount,
                        batchTotal = uiState.batchTotalCount,
                        mergedMasterWavPath = uiState.mergedMasterWavPath,
                        mergedMasterDurationMs = uiState.mergedMasterDurationMs,
                        playingFilePath = playingFilePath,
                        onGenerateAllBackground = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            studioViewModel.generateFullStoryInBackground()
                        },
                        onMergeAndPlayMasterWav = studioViewModel::mergeAllAndPlayMasterWav,
                        onExportSrtClick = studioViewModel::exportSrtSubtitles,
                        onPlayOrStopMaster = studioViewModel::playOrStopWav
                    )
                }
            }
        }
    }

    if (uiState.showDiagnosticsSheet) {
        DiagnosticsBottomSheet(
            report = uiState.diagnosticsReport,
            isRunning = uiState.isRunningDiagnostics,
            onRerunCheck = studioViewModel::openDiagnosticsAndRunCheck,
            onRequestNotificationPermission = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            },
            onDismiss = studioViewModel::closeDiagnosticsSheet
        )
    }

    if (uiState.showKeyManagerDialog) {
        ApiKeyManagerDialog(
            manualKeyInput = uiState.manualKeyInput,
            isTestingKey = uiState.isTestingManualKey,
            testStatusMessage = uiState.manualKeyTestStatus,
            testPassed = uiState.manualKeyTestPassed,
            slotLabels = uiState.rotationSlotLabels,
            activeSlotIndex = uiState.activeRotationSlotIndex,
            onKeyInputChange = studioViewModel::updateManualKeyInput,
            onTestKeyClick = studioViewModel::testManualKeyConnection,
            onAddKeyClick = studioViewModel::addManualKeyToRotationPool,
            onSelectSlot = studioViewModel::selectActiveKeySlot,
            onRemoveSlot = studioViewModel::removeKeySlot,
            onSimulate429Rotate = studioViewModel::rotateKeySlotOnRateLimitSimulation,
            onDismiss = studioViewModel::closeKeyManagerDialog
        )
    }

    if (uiState.showSrtDialog && uiState.exportedSrtContent != null) {
        SrtExportDialog(
            srtContent = uiState.exportedSrtContent!!,
            onDismiss = studioViewModel::dismissSrtDialog,
            onShareSrt = { srt ->
                studioViewModel.shareTextContent(
                    context = context,
                    title = "Bengali Story Subtitles (.SRT)",
                    content = srt
                )
            }
        )
    }
}

@Composable
private fun DirectorAndCardsWorkspace(
    scriptInput: String,
    isAnalyzing: Boolean,
    cards: List<com.example.data.model.DialogueCard>,
    playingFilePath: String?,
    isBatchGenerating: Boolean,
    batchCompleted: Int,
    batchTotal: Int,
    onScriptChange: (String) -> Unit,
    onAnalyzeClick: () -> Unit,
    onResetSampleClick: () -> Unit,
    onSelectPreset: (String, String) -> Unit,
    onSelectVoice: (String, String) -> Unit,
    onApplyEmotionChip: (String, String) -> Unit,
    onEmotionTextChange: (String, String) -> Unit,
    onPauseChange: (String, Float) -> Unit,
    onDialogueTextChange: (String, String) -> Unit,
    onMicroPreviewClick: (String) -> Unit,
    onOfflineDraftClick: (com.example.data.model.DialogueCard) -> Unit,
    onGenerateVoiceClick: (String) -> Unit,
    onPlayOrStopWavClick: (String) -> Unit,
    onDeleteCardClick: (String) -> Unit,
    onAddCardClick: () -> Unit,
    onBatchGenerateClick: () -> Unit,
    onMergeMasterWavClick: () -> Unit,
    onExportSrtClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("studio_director_lazy_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Stage 1: AI Acting Director
        item {
            ActingDirectorScriptCard(
                scriptInput = scriptInput,
                isAnalyzing = isAnalyzing,
                onScriptChange = onScriptChange,
                onAnalyzeClick = onAnalyzeClick,
                onResetSampleClick = onResetSampleClick
            )
        }

        // Master Batch Controls & Merger Toolbar
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = StudioSurface,
                border = BorderStroke(1.dp, StudioGlassBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "STAGE 2 • Dialogue Cards & Batch Studio",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${cards.size} Dialogue Lines • 24kHz 16-bit Mono WAV",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonCyan
                            )
                        }
                        OutlinedButton(
                            onClick = onAddCardClick,
                            border = BorderStroke(1.dp, NeonCyan),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("add_dialogue_card_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Card", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                        }
                    }

                    if (isBatchGenerating) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Background Batch Synthesis: $batchCompleted / $batchTotal cards completed...",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldMint
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = {
                                if (batchTotal > 0) batchCompleted.toFloat() / batchTotal.toFloat() else 0f
                            },
                            modifier = Modifier.fillMaxWidth(),
                            color = EmeraldMint,
                            trackColor = StudioSurfaceElevated
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onBatchGenerateClick,
                        enabled = !isBatchGenerating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("generate_full_story_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricViolet,
                            contentColor = Color(0xFF150433)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.AudioFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generate Full Story in Background", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onMergeMasterWavClick,
                            enabled = !isBatchGenerating,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("quick_merge_wav_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldMint,
                                contentColor = Color(0xFF002411)
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.MergeType, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Merge All .WAV",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = onExportSrtClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("quick_export_srt_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, NeonCyan),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ClosedCaption,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Export .SRT",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Individual Dialogue Cards
        itemsIndexed(cards, key = { _, item -> item.id }) { idx, card ->
            DialogueEditorCardItem(
                index = idx,
                card = card,
                isPlayingThisCard = card.wavFilePath != null && playingFilePath == card.wavFilePath,
                onSelectPreset = { newKey -> onSelectPreset(card.id, newKey) },
                onSelectVoice = { newVoice -> onSelectVoice(card.id, newVoice) },
                onApplyEmotionChip = { chipDir -> onApplyEmotionChip(card.id, chipDir) },
                onEmotionTextChange = { newEmo -> onEmotionTextChange(card.id, newEmo) },
                onPauseChange = { newPause -> onPauseChange(card.id, newPause) },
                onDialogueTextChange = { newTxt -> onDialogueTextChange(card.id, newTxt) },
                onMicroPreviewClick = { onMicroPreviewClick(card.id) },
                onOfflineDraftClick = { onOfflineDraftClick(card) },
                onGenerateVoiceClick = { onGenerateVoiceClick(card.id) },
                onPlayOrStopWavClick = { card.wavFilePath?.let(onPlayOrStopWavClick) },
                onDeleteCardClick = { onDeleteCardClick(card.id) }
            )
        }
    }
}
